﻿using System;

namespace $rootnamespace$ 
{
    class $safeitemname$
    {
        static void Main(string[] args)
        {
            // ここにコードを入力
        }
    }
}
